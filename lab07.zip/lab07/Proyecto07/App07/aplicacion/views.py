from django.shortcuts import render

# Create your views here.

from .models import Categoria,Libros
def all_Categoria(request):
    template_name = "index1.html"
    #mostrar todas las ccategorias comandos orm
    #select * from categoria
    cate = Categoria.objects.all()
    books= Libros.objects.all()
    #books = Libros.objects.filter(Categoria_id = 1)
    context = {
        'categoria': cate,
        'books': books

    }
    return render(request, template_name,  context)