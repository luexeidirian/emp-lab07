from django.urls import path

from .views import all_Categoria

urlpatterns = [
    path('', all_Categoria, name="all_Categoria"),
]